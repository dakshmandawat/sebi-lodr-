"""
app.py — Flask AI microservice entry point.
Port: 5000
Rate limiting: 30 req/min per IP (flask-limiter) — AI Developer 2 responsibility
"""

import os
import logging
from dotenv import load_dotenv

# Load .env before anything else
load_dotenv()

from flask import Flask, jsonify
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

# ─────────────────────────────────────────────
# App factory
# ─────────────────────────────────────────────

def create_app():
    app = Flask(__name__)

    # ── Logging ──────────────────────────────
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # ── Security headers (fix OWASP ZAP findings) ────────────────────────────
    @app.after_request
    def add_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Content-Security-Policy"] = "default-src 'none'"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        return response

    # ── Rate Limiter — 30 req/min per IP ─────
    redis_url = os.getenv("REDIS_URL", "memory://")
    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        default_limits=["30 per minute"],
        storage_uri=redis_url,
        headers_enabled=True,     # Adds X-RateLimit-* headers
    )

    # ── Register blueprints ───────────────────
    from routes.health import health_bp
    from routes.ai_endpoints import ai_bp
    from routes.report import report_bp

    app.register_blueprint(health_bp)
    app.register_blueprint(ai_bp)
    app.register_blueprint(report_bp)

    # ── Global error handlers ─────────────────
    @app.errorhandler(429)
    def rate_limit_exceeded(e):
        return jsonify({
            "error": "Rate limit exceeded. Maximum 30 requests per minute.",
            "code": "RATE_LIMIT_EXCEEDED"
        }), 429

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Endpoint not found.", "code": "NOT_FOUND"}), 404

    @app.errorhandler(405)
    def method_not_allowed(e):
        return jsonify({"error": "Method not allowed.", "code": "METHOD_NOT_ALLOWED"}), 405

    @app.errorhandler(500)
    def internal_error(e):
        return jsonify({"error": "Internal server error.", "code": "INTERNAL_ERROR"}), 500

    return app


app = create_app()

if __name__ == "__main__":
    port = int(os.getenv("AI_SERVICE_PORT", 5000))
    debug = os.getenv("FLASK_DEBUG", "false").lower() == "true"
    app.run(host="0.0.0.0", port=port, debug=debug)
