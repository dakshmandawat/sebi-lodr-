"""conftest.py — pytest configuration for AI service tests."""
import sys
import os

# Add parent directory to path so imports work
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Set dummy env vars before any imports
os.environ.setdefault("GROQ_API_KEY", "test-key-not-real")
os.environ.setdefault("FLASK_DEBUG", "false")
