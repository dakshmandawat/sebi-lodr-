"""
groq_client.py — GroqClient with 3-retry backoff, error logging, and fallback support.
"""

import os
import time
import logging
from groq import Groq

logger = logging.getLogger(__name__)

GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
MAX_TOKENS = int(os.getenv("GROQ_MAX_TOKENS", "1024"))
TEMPERATURE_FACTUAL = 0.3
TEMPERATURE_CREATIVE = 0.7


class GroqClient:
    def __init__(self):
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            raise EnvironmentError("GROQ_API_KEY is not set in environment variables.")
        self.client = Groq(api_key=api_key)

    def call(self, messages: list, temperature: float = TEMPERATURE_FACTUAL, max_retries: int = 3):
        attempt = 0
        backoff = 2
        while attempt < max_retries:
            try:
                logger.info(f"Groq API call attempt {attempt + 1}/{max_retries}")
                response = self.client.chat.completions.create(
                    model=GROQ_MODEL,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=MAX_TOKENS,
                )
                content = response.choices[0].message.content
                logger.info("Groq API call succeeded.")
                return content
            except Exception as e:
                attempt += 1
                logger.error(f"Groq API error on attempt {attempt}: {type(e).__name__}: {e}")
                if attempt < max_retries:
                    logger.info(f"Retrying in {backoff}s...")
                    time.sleep(backoff)
                    backoff *= 2
                else:
                    logger.error("All Groq retry attempts exhausted. Returning None.")
                    return None

    def call_factual(self, messages: list):
        return self.call(messages, temperature=TEMPERATURE_FACTUAL)

    def call_creative(self, messages: list):
        return self.call(messages, temperature=TEMPERATURE_CREATIVE)


# Lazy singleton — initialized on first use, not at import time
_groq_client_instance = None

def get_groq_client():
    global _groq_client_instance
    if _groq_client_instance is None:
        try:
            _groq_client_instance = GroqClient()
            logger.info("GroqClient initialized successfully.")
        except Exception as e:
            logger.error(f"Failed to initialize GroqClient: {e}")
            return None
    return _groq_client_instance

# Keep backward-compatible name
groq_client = None  # routes import this — they must call get_groq_client() instead
