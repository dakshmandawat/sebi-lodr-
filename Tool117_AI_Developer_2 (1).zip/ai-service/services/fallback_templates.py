# fallback_templates.py — Static fallback responses when Groq API is unavailable.
# AI Developer 2 responsibility: these ensure the app never returns HTTP 500 due to AI downtime.

from datetime import datetime, timezone


def _now():
    return datetime.now(timezone.utc).isoformat()


DESCRIBE_FALLBACK = {
    "plain_english_summary": "AI service is temporarily unavailable. Please review the obligation details manually and consult the SEBI LODR 2015 guidelines.",
    "legal_basis": "Refer to the applicable SEBI LODR 2015 regulation for this category.",
    "compliance_steps": [
        "Step 1: Review the obligation details carefully.",
        "Step 2: Consult your compliance team or legal counsel.",
        "Step 3: Document actions taken and update status."
    ],
    "common_pitfalls": [
        "Missing submission deadlines",
        "Incomplete disclosure documentation"
    ],
    "consequence_of_non_compliance": "Non-compliance may result in regulatory penalties per SEBI LODR 2015.",
    "complexity_level": "Medium",
    "estimated_effort_days": 3,
    "is_fallback": True,
}


RECOMMEND_FALLBACK = {
    "recommendations": [
        {
            "action_type": "Immediate Action",
            "description": "Review the current compliance status and assign a responsible team member immediately. Ensure all required documentation is gathered.",
            "priority": "High",
            "timeline": "Today",
            "expected_outcome": "Clear ownership and initial assessment completed.",
            "regulation_ref": "Refer to applicable SEBI LODR 2015 regulation."
        },
        {
            "action_type": "Process Improvement",
            "description": "Establish a recurring calendar reminder for this obligation type. Create a standard checklist to ensure all steps are followed consistently.",
            "priority": "Medium",
            "timeline": "7 days",
            "expected_outcome": "Reduced risk of missing future deadlines for this obligation.",
            "regulation_ref": "Refer to applicable SEBI LODR 2015 regulation."
        },
        {
            "action_type": "Preventive Measure",
            "description": "Schedule a quarterly review of all SEBI LODR obligations with your compliance team to identify gaps early and take proactive corrective action.",
            "priority": "Low",
            "timeline": "30 days",
            "expected_outcome": "Improved overall compliance posture with fewer last-minute escalations.",
            "regulation_ref": "General SEBI LODR 2015 compliance framework."
        }
    ],
    "overall_risk": "Medium",
    "is_fallback": True,
}


REPORT_FALLBACK = {
    "title": "SEBI LODR Compliance Report — AI Service Unavailable",
    "summary": "The AI report generation service is temporarily unavailable. This is a fallback report. Please retry shortly or generate the report manually from the compliance data.",
    "compliance_score": 0,
    "overview": {
        "total_obligations": 0,
        "compliant": 0,
        "non_compliant": 0,
        "pending": 0,
        "compliance_percentage": 0.0
    },
    "key_findings": [
        {
            "area": "AI Service",
            "status": "Non-Compliant",
            "finding": "AI report generation is temporarily unavailable. Data has been preserved and the report can be regenerated.",
            "regulation_ref": "N/A"
        }
    ],
    "recommendations": [
        {
            "priority": "High",
            "action": "Retry report generation once the AI service is restored.",
            "timeline": "Immediate",
            "regulation_ref": "N/A"
        }
    ],
    "risk_assessment": "Unable to assess risk automatically at this time. Please conduct a manual review of all open compliance items.",
    "is_fallback": True,
}


def get_describe_fallback() -> dict:
    f = DESCRIBE_FALLBACK.copy()
    f["generated_at"] = _now()
    return f


def get_recommend_fallback() -> dict:
    f = RECOMMEND_FALLBACK.copy()
    f["generated_at"] = _now()
    return f


def get_report_fallback() -> dict:
    f = REPORT_FALLBACK.copy()
    f["generated_at"] = _now()
    return f
