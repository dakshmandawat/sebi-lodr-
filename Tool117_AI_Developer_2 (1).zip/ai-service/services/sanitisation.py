"""
sanitisation.py — Input sanitisation middleware for the AI service.
AI Developer 2 responsibility: Day 3
- Strip HTML tags from all string inputs
- Detect prompt injection attempts
- Return 400 with clear error message on suspicious input
"""

import re
import bleach
import logging
from flask import request, jsonify
from functools import wraps

logger = logging.getLogger(__name__)

# Patterns that indicate prompt injection attempts
INJECTION_PATTERNS = [
    r"ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|prompts?|context)",
    r"you\s+are\s+now\s+(a\s+)?(?!sebi|compliance)",    # "you are now a [different AI]"
    r"disregard\s+(all\s+)?(previous|prior|above|your)",
    r"forget\s+(everything|all|your\s+instructions)",
    r"act\s+as\s+(if\s+you\s+are\s+)?(a\s+)?(?!sebi|compliance)",
    r"new\s+instruction[s]?:",
    r"system\s*:",                                         # Fake system prompt injection
    r"<\s*/?system\s*>",
    r"\[INST\]|\[/INST\]",                                # LLaMA-style injection
    r"###\s*(instruction|system|human|assistant)",
    r"jailbreak",
    r"dan\s+mode",                                        # DAN jailbreak
]

COMPILED_PATTERNS = [re.compile(p, re.IGNORECASE) for p in INJECTION_PATTERNS]

MAX_FIELD_LENGTH = 5000  # characters


def sanitise_string(value: str) -> str:
    """Strip HTML tags and limit length."""
    if not isinstance(value, str):
        return value
    cleaned = bleach.clean(value, tags=[], strip=True)  # remove all HTML
    return cleaned[:MAX_FIELD_LENGTH]


def detect_injection(value: str) -> bool:
    """Return True if the string looks like a prompt injection attempt."""
    if not isinstance(value, str):
        return False
    for pattern in COMPILED_PATTERNS:
        if pattern.search(value):
            return True
    return False


def sanitise_dict(data: dict) -> tuple[dict, str | None]:
    """
    Recursively sanitise all string values in a dict.
    Returns (sanitised_dict, error_message_or_None).
    """
    sanitised = {}
    for key, value in data.items():
        if isinstance(value, str):
            if detect_injection(value):
                logger.warning(f"Prompt injection detected in field '{key}': {value[:100]}")
                return {}, f"Suspicious input detected in field '{key}'. Request rejected."
            sanitised[key] = sanitise_string(value)
        elif isinstance(value, dict):
            inner, err = sanitise_dict(value)
            if err:
                return {}, err
            sanitised[key] = inner
        elif isinstance(value, list):
            clean_list = []
            for item in value:
                if isinstance(item, str):
                    if detect_injection(item):
                        logger.warning(f"Prompt injection detected in list field '{key}'")
                        return {}, f"Suspicious input detected in field '{key}'. Request rejected."
                    clean_list.append(sanitise_string(item))
                else:
                    clean_list.append(item)
            sanitised[key] = clean_list
        else:
            sanitised[key] = value
    return sanitised, None


def sanitise_input(f):
    """
    Flask decorator: sanitise all incoming JSON body fields.
    - Strip HTML
    - Detect prompt injection → 400
    Usage: @sanitise_input on any route handler
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        if request.is_json and request.content_length and request.content_length > 0:
            data = request.get_json(silent=True)
            if data is None:
                return jsonify({"error": "Invalid JSON body."}), 400

            if isinstance(data, dict):
                sanitised, err = sanitise_dict(data)
                if err:
                    return jsonify({"error": err, "code": "INJECTION_DETECTED"}), 400
                # Replace request json with sanitised version
                request._cached_json = (sanitised, sanitised)

        return f(*args, **kwargs)
    return decorated
