# AI Developer 2 — Demo Day Summary Card
## Tool-117 SEBI LODR Compliance Manager | 9 May 2026

---

## Tech Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| AI Model | LLaMA-3.3-70b via Groq API | Free tier LLM, no credit card |
| AI Framework | Flask 3.x (Python 3.11) | REST microservice on port 5000 |
| Rate Limiting | flask-limiter | 30 req/min per IP |
| Input Safety | bleach + regex patterns | HTML strip + injection detection |
| Retry Logic | Custom (3 retries, exponential backoff) | Groq outage tolerance |

---

## AI Endpoints (Port 5000)

### POST /describe
- **Input:** title, category, description, due_date, company_type
- **Output:** plain_english_summary, legal_basis, compliance_steps, complexity_level
- **Use case:** Explain a compliance obligation in plain English

### POST /recommend
- **Input:** title, status, category, due_date, risk_level, notes
- **Output:** 3 recommendations (action_type, description, priority, timeline)
- **Use case:** Get actionable next steps for a compliance item

### POST /generate-report
- **Input:** company_name, period, counts (compliant/non-compliant/pending)
- **Output:** Full report (title, summary, score, key_findings, recommendations)
- **Use case:** Generate a formatted compliance report with AI insights

### GET /health
- **Output:** status, model, uptime, avg_response_time, endpoints list
- **Use case:** Monitor AI service status

---

## Security Highlights (My Responsibility)

- ✅ Prompt injection detection — 10+ regex patterns, HTTP 400 on detection
- ✅ HTML sanitisation — bleach strips all tags before Groq call
- ✅ Rate limiting — 30 req/min per IP, HTTP 429 with clear message
- ✅ Security headers — X-Frame-Options, CSP, HSTS, nosniff on every response
- ✅ No PII in prompts — verified by manual audit
- ✅ API key in .env only — never hardcoded, .gitignore on Day 1
- ✅ OWASP ZAP: 0 Critical, 0 High findings
- ✅ Fallback templates — Groq outage returns is_fallback:true, never HTTP 500

---

## What to Say During Demo (60-second AI explanation)

> "The AI service is a Python Flask microservice running on port 5000. It uses the Groq API to run LLaMA-3.3-70b, a 70-billion parameter model — completely free, no credit card needed.
>
> When you create a compliance obligation, the Java backend calls our /describe endpoint asynchronously. The model reads our prompt template, fills in the obligation details, and returns structured JSON — plain-English summary, compliance steps, legal references.
>
> Before any text reaches the model, our sanitisation middleware strips HTML and checks for prompt injection attempts. If someone tries to manipulate the AI, they get a 400 error. If Groq is unavailable, we return a fallback template — the app never crashes."

---

**GitHub:** [your-repo-link-here]
**Sprint:** 14 April – 9 May 2026 | **Demo Day:** 9 May 2026
