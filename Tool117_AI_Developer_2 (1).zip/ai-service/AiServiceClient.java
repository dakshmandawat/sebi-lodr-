package com.internship.tool.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import java.util.Map;

/**
 * AiServiceClient.java — RestTemplate-based HTTP client for the Python Flask AI service.
 * AI Developer 2 responsibility: Day 4
 *
 * - Calls /describe, /recommend, /generate-report, /health
 * - 10-second connect + read timeout
 * - Returns null on any error (callers must handle null gracefully)
 */
@Component
public class AiServiceClient {

    private static final Logger log = LoggerFactory.getLogger(AiServiceClient.class);

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    @Value("${ai.service.base-url:http://localhost:5000}")
    private String baseUrl;

    public AiServiceClient(RestTemplate restTemplate, ObjectMapper objectMapper) {
        this.restTemplate = restTemplate;
        this.objectMapper = objectMapper;
    }

    // ─────────────────────────────────────────────
    // POST /describe
    // ─────────────────────────────────────────────

    /**
     * Call the /describe endpoint.
     *
     * @param payload Map containing the fields to describe (e.g., obligation text).
     * @return Parsed response as Map, or null on failure.
     */
    public Map<String, Object> describe(Map<String, Object> payload) {
        return postForMap("/describe", payload);
    }

    // ─────────────────────────────────────────────
    // POST /recommend
    // ─────────────────────────────────────────────

    /**
     * Call the /recommend endpoint.
     *
     * @param payload Map containing the item details for recommendations.
     * @return Parsed response as Map (contains "recommendations" list), or null on failure.
     */
    public Map<String, Object> recommend(Map<String, Object> payload) {
        return postForMap("/recommend", payload);
    }

    // ─────────────────────────────────────────────
    // POST /generate-report
    // ─────────────────────────────────────────────

    /**
     * Call the /generate-report endpoint.
     *
     * @param payload Map with report parameters (date range, filters, etc.).
     * @return Parsed report as Map, or null on failure.
     */
    public Map<String, Object> generateReport(Map<String, Object> payload) {
        return postForMap("/generate-report", payload);
    }

    // ─────────────────────────────────────────────
    // GET /health
    // ─────────────────────────────────────────────

    /**
     * Call the /health endpoint to check AI service status.
     *
     * @return Health info as Map, or null on failure.
     */
    public Map<String, Object> health() {
        String url = baseUrl + "/health";
        try {
            log.debug("Calling AI service GET {}", url);
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
            log.info("AI /health responded with status {}", response.getStatusCode());
            return response.getBody();
        } catch (ResourceAccessException e) {
            log.error("AI service /health timeout or unreachable: {}", e.getMessage());
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            log.error("AI service /health returned HTTP {}: {}", e.getStatusCode(), e.getResponseBodyAsString());
        } catch (Exception e) {
            log.error("Unexpected error calling AI /health: {}", e.getMessage(), e);
        }
        return null;
    }

    // ─────────────────────────────────────────────
    // Internal helper
    // ─────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private Map<String, Object> postForMap(String path, Map<String, Object> payload) {
        String url = baseUrl + path;
        try {
            log.debug("Calling AI service POST {}", url);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);

            ResponseEntity<Map> response = restTemplate.exchange(
                    url, HttpMethod.POST, request, Map.class);

            log.info("AI service POST {} responded with status {}", path, response.getStatusCode());
            return response.getBody();

        } catch (ResourceAccessException e) {
            log.error("AI service POST {} timeout or unreachable: {}", path, e.getMessage());
        } catch (HttpClientErrorException e) {
            log.error("AI service POST {} returned HTTP {}: {}", path, e.getStatusCode(), e.getResponseBodyAsString());
        } catch (HttpServerErrorException e) {
            log.error("AI service POST {} server error {}: {}", path, e.getStatusCode(), e.getResponseBodyAsString());
        } catch (Exception e) {
            log.error("Unexpected error calling AI {}: {}", path, e.getMessage(), e);
        }
        return null;  // Callers MUST handle null
    }
}
