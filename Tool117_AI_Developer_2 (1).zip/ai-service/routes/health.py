"""
health.py — GET /health endpoint.
Returns model info, avg response time, uptime, and cache status.
"""

import time
import logging
from datetime import datetime, timezone
from flask import Blueprint, jsonify

logger = logging.getLogger(__name__)

health_bp = Blueprint("health", __name__)

# Module-level start time for uptime calculation
_START_TIME = time.time()


@health_bp.route("/health", methods=["GET"])
def health():
    """
    GET /health
    Returns AI service health information.
    """
    import os
    uptime_seconds = int(time.time() - _START_TIME)
    hours, remainder = divmod(uptime_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)

    return jsonify({
        "status": "healthy",
        "model": os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile"),
        "uptime": f"{hours}h {minutes}m {seconds}s",
        "uptime_seconds": uptime_seconds,
        "avg_response_time_ms": "varies — see logs",
        "rate_limit": "30 requests/minute per IP",
        "endpoints": ["/describe", "/recommend", "/generate-report", "/health"],
        "cache_backend": "Redis" if os.getenv("REDIS_URL") else "None (Redis not configured)",
        "checked_at": datetime.now(timezone.utc).isoformat(),
    }), 200
