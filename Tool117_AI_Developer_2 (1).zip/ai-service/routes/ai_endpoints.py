"""
ai_endpoints.py — POST /describe and POST /recommend endpoints.
"""

import json
import logging
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify

from services.sanitisation import sanitise_input
from services.fallback_templates import get_describe_fallback, get_recommend_fallback
from services.groq_client import get_groq_client

logger = logging.getLogger(__name__)
ai_bp = Blueprint("ai", __name__)


def load_prompt(filename: str) -> str:
    try:
        with open(f"prompts/{filename}", "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        logger.error(f"Prompt file {filename} not found.")
        return ""


def parse_groq_json(raw: str):
    try:
        clean = raw.strip()
        if clean.startswith("```"):
            parts = clean.split("```")
            clean = parts[1]
            if clean.startswith("json"):
                clean = clean[4:]
        return json.loads(clean)
    except (json.JSONDecodeError, IndexError, ValueError):
        return None


@ai_bp.route("/describe", methods=["POST"])
@sanitise_input
def describe():
    data = request.get_json(silent=True) or {}

    if not data.get("title"):
        return jsonify({"error": "Field 'title' is required."}), 400

    generated_at = datetime.now(timezone.utc).isoformat()
    prompt_template = load_prompt("describe.txt")
    groq = get_groq_client()

    if not prompt_template or groq is None:
        return jsonify(get_describe_fallback()), 200

    prompt = prompt_template.format(
        title=data.get("title", ""),
        category=data.get("category", "General"),
        description=data.get("description", ""),
        due_date=data.get("due_date", "Not specified"),
        company_type=data.get("company_type", "Listed Entity"),
        generated_at=generated_at,
    )

    messages = [
        {"role": "system", "content": "You are a SEBI LODR compliance expert. Return only valid JSON."},
        {"role": "user", "content": prompt}
    ]

    raw = groq.call_factual(messages)
    if raw is None:
        return jsonify(get_describe_fallback()), 200

    result = parse_groq_json(raw)
    if result is None:
        return jsonify(get_describe_fallback()), 200

    result["generated_at"] = generated_at
    result.setdefault("is_fallback", False)
    return jsonify(result), 200


@ai_bp.route("/recommend", methods=["POST"])
@sanitise_input
def recommend():
    data = request.get_json(silent=True) or {}

    if not data.get("title"):
        return jsonify({"error": "Field 'title' is required."}), 400

    generated_at = datetime.now(timezone.utc).isoformat()
    prompt_template = load_prompt("recommend.txt")
    groq = get_groq_client()

    if not prompt_template or groq is None:
        return jsonify(get_recommend_fallback()), 200

    prompt = prompt_template.format(
        title=data.get("title", ""),
        status=data.get("status", "Pending"),
        category=data.get("category", "General"),
        due_date=data.get("due_date", "Not specified"),
        risk_level=data.get("risk_level", "Medium"),
        notes=data.get("notes", "None"),
        generated_at=generated_at,
    )

    messages = [
        {"role": "system", "content": "You are a SEBI LODR compliance expert. Return only valid JSON."},
        {"role": "user", "content": prompt}
    ]

    raw = groq.call_factual(messages)
    if raw is None:
        return jsonify(get_recommend_fallback()), 200

    result = parse_groq_json(raw)
    if result is None:
        return jsonify(get_recommend_fallback()), 200

    result["generated_at"] = generated_at
    result.setdefault("is_fallback", False)
    return jsonify(result), 200
