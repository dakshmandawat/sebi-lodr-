"""
report.py — POST /generate-report endpoint.
"""

import json
import logging
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify

from services.sanitisation import sanitise_input
from services.fallback_templates import get_report_fallback
from services.groq_client import get_groq_client

logger = logging.getLogger(__name__)
report_bp = Blueprint("report", __name__)

REQUIRED_FIELDS = ["company_name", "period"]


def load_prompt() -> str:
    try:
        with open("prompts/generate_report.txt", "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        logger.error("generate_report.txt prompt template not found.")
        return ""


@report_bp.route("/generate-report", methods=["POST"])
@sanitise_input
def generate_report():
    data = request.get_json(silent=True) or {}

    missing = [f for f in REQUIRED_FIELDS if not data.get(f)]
    if missing:
        return jsonify({"error": f"Missing required fields: {', '.join(missing)}"}), 400

    generated_at = datetime.now(timezone.utc).isoformat()
    prompt_template = load_prompt()
    groq = get_groq_client()

    if not prompt_template or groq is None:
        return jsonify(get_report_fallback()), 200

    prompt = prompt_template.format(
        company_name=data.get("company_name", "Unknown"),
        period=data.get("period", "Unknown"),
        total_obligations=data.get("total_obligations", 0),
        compliant_count=data.get("compliant_count", 0),
        non_compliant_count=data.get("non_compliant_count", 0),
        pending_count=data.get("pending_count", 0),
        key_areas=data.get("key_areas", "General compliance"),
        generated_at=generated_at,
    )

    messages = [
        {"role": "system", "content": "You are a SEBI LODR compliance expert. Always return only valid JSON. No markdown. No explanation."},
        {"role": "user", "content": prompt}
    ]

    raw_response = groq.call_factual(messages)
    if raw_response is None:
        return jsonify(get_report_fallback()), 200

    try:
        clean = raw_response.strip()
        if clean.startswith("```"):
            clean = clean.split("```")[1]
            if clean.startswith("json"):
                clean = clean[4:]
        result = json.loads(clean)
        result["generated_at"] = generated_at
        result.setdefault("is_fallback", False)
        return jsonify(result), 200
    except (json.JSONDecodeError, ValueError) as e:
        logger.error(f"Failed to parse Groq JSON for /generate-report: {e}")
        return jsonify(get_report_fallback()), 200
