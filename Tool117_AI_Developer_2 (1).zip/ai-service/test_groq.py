"""
test_groq.py — Quick smoke test to confirm Groq API key is valid and working.
Run this on Day 1 after setting GROQ_API_KEY in your .env file.

Usage:
    python test_groq.py
"""

import os
import sys
from dotenv import load_dotenv

load_dotenv()


def test_groq_connection():
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        print("[FAIL] GROQ_API_KEY is not set. Add it to your .env file.")
        sys.exit(1)

    print(f"[INFO] GROQ_API_KEY found: {api_key[:8]}...")

    try:
        from groq import Groq
        client = Groq(api_key=api_key)

        print("[INFO] Sending test message to Groq API...")
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {
                    "role": "user",
                    "content": "Say 'SEBI LODR test OK' and nothing else."
                }
            ],
            max_tokens=20,
            temperature=0.0,
        )

        reply = response.choices[0].message.content.strip()
        print(f"[OK] Groq API response: {reply}")
        print("[PASS] Groq API connection is working correctly.")

    except ImportError:
        print("[FAIL] groq package not installed. Run: pip install groq")
        sys.exit(1)
    except Exception as e:
        print(f"[FAIL] Groq API call failed: {type(e).__name__}: {e}")
        sys.exit(1)


if __name__ == "__main__":
    test_groq_connection()
